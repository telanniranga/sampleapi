# sample-cicd

This is a sample project with an Angular front end and .NET back-end. Utilizing the power of Gitlab CICD. 
Refer to this as the primary POC Example.